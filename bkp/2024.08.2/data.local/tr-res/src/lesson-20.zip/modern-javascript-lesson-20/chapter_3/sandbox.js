// while loops
const names = ['shaun', 'mario', 'luigi'];
let i = 0;

// while(i < 5){
//   console.log('loop: ', i);
//   i++;
// }

// while(i < names.length){
//   console.log(names[i]);
//   i++;
// }

i = 8;
while(i > 5){
  console.log('loop: ', i);
  i--;
}
