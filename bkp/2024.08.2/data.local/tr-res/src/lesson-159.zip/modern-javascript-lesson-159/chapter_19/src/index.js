// import './dom';
import { styleBody, addTitle, contact } from './dom';

console.log('index.js file');

addTitle('hello, world from index.js');
styleBody();

console.log(contact);