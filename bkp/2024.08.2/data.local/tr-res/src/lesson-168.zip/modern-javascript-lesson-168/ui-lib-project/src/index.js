import Tooltip from './ninja-ui/tooltip';

// create tooltip
const tooltip = new Tooltip(document.querySelector('.tooltip'));
tooltip.init();