"use strict";

var greet = function greet(name) {
  console.log("hello ".concat(name));
};

greet();
