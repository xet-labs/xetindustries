const greet = name => {
  console.log(`hello ${name}`);
};

greet('mario');
greet('luigi');
greet('link');
greet('chun-li');