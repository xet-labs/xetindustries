let age = 25;
let year = 2019;

console.log(age, year);

// age = 30;
// console.log(age);

// const points = 100;
// points = 50;
// console.log(points);

// var score = 75;
// console.log(score);
